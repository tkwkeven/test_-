/*
 * Copyright 2011 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.json.bvtVO;

/**
 * 类OptionKey.java的实现描述：TODO 类实现描述
 * 
 * @author lei.yaol 2011-12-27 下午03:40:45
 */
public enum OptionKey {
    TEMPLATE_REOUSRCE_ID, TEMPALTE_ATTACH_META, RESEND_LOG_ID;
}
