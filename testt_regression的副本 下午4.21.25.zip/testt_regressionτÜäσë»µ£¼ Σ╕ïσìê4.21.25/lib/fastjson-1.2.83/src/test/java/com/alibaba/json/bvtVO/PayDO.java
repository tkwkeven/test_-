package com.alibaba.json.bvtVO;

public class PayDO {

    public Integer getCurrentSubPayOrder() {
        throw new RuntimeException("non getter getXXX method should not be called");
    }
}
